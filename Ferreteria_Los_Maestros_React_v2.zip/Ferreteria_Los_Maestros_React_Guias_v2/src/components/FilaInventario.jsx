import { Badge } from "react-bootstrap";

function FilaInventario({ producto }) {
  const bajo = producto.stock <= producto.stockMinimo;

  return (
    <tr>
      <th scope="row">{producto.codigo}</th>
      <td>{producto.nombre}</td>
      <td>{producto.categoria}</td>
      <td>{producto.stock}</td>
      <td>{producto.stockMinimo}</td>
      <td>
        <Badge bg={bajo ? "warning" : "success"} text={bajo ? "dark" : undefined}>
          {bajo ? "Stock bajo" : "Disponible"}
        </Badge>
      </td>
    </tr>
  );
}

export default FilaInventario;
