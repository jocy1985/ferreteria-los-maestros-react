import { Container } from "react-bootstrap";
import ListaProductos from "../components/ListaProductos";
import { useCarrito } from "../context/CarritoContext";
import { useProductos } from "../context/ProductosContext";

function Ofertas() {
  const { productos } = useProductos();
  const { agregarProducto } = useCarrito();
  const productosEnOferta = productos.filter((producto) => producto.precioOferta);

  return (
    <Container className="py-5">
      <header className="mb-4">
        <p className="etiqueta">Precios especiales</p>
        <h1>Ofertas</h1>
        <p className="lead">Productos seleccionados con precio promocional.</p>
      </header>
      <ListaProductos productos={productosEnOferta} onAgregar={agregarProducto} />
    </Container>
  );
}

export default Ofertas;
