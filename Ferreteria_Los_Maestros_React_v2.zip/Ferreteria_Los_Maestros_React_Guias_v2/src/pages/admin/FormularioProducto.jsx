import { useState } from "react";
import { Alert, Button, Col, Form, Modal, Row } from "react-bootstrap";

const inicial = {
  codigo: "",
  nombre: "",
  categoria: "",
  marca: "",
  unidad: "unidad",
  precio: "",
  precioOferta: "",
  stock: "",
  stockMinimo: "",
  descripcion: "",
  imagen: "",
};

function datosIniciales(producto) {
  if (!producto) return inicial;

  return {
    ...inicial,
    ...producto,
    precioOferta: producto.precioOferta ?? "",
  };
}

function FormularioProducto({ producto, onGuardar, onCancelar }) {
  const [datos, setDatos] = useState(() => datosIniciales(producto));
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState("");
  const editando = Boolean(producto);

  function cambiar(evento) {
    const { name, value } = evento.target;

    setDatos((actual) => ({
      ...actual,
      [name]: value,
    }));

    setErrores((actuales) => ({
      ...actuales,
      [name]: "",
    }));
    setErrorGeneral("");
  }

  function enviar(evento) {
    evento.preventDefault();

    const nuevosErrores = {};

    if (!datos.codigo.trim()) nuevosErrores.codigo = "Código obligatorio";
    if (!datos.nombre.trim()) nuevosErrores.nombre = "Nombre obligatorio";
    if (!datos.categoria.trim()) nuevosErrores.categoria = "Categoría obligatoria";
    if (!datos.marca.trim()) nuevosErrores.marca = "Marca obligatoria";
    if (Number(datos.precio) <= 0) nuevosErrores.precio = "El precio debe ser mayor que cero";
    if (Number(datos.stock) < 0) nuevosErrores.stock = "El stock no puede ser negativo";
    if (Number(datos.stockMinimo) < 0) nuevosErrores.stockMinimo = "El stock mínimo no puede ser negativo";

    setErrores(nuevosErrores);

    if (Object.keys(nuevosErrores).length > 0) {
      setErrorGeneral("Completa los campos obligatorios y utiliza valores numéricos válidos.");
      return;
    }

    const resultado = onGuardar(datos);

    if (resultado && !resultado.ok) {
      setErrorGeneral(resultado.mensaje);
    }
  }

  return (
    <Form onSubmit={enviar} noValidate>
      <Modal.Header closeButton>
        <Modal.Title>{editando ? "Editar producto" : "Nuevo producto"}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {errorGeneral && <Alert variant="danger">{errorGeneral}</Alert>}

        <Row className="g-3">
          <Col xs={12} md={4}>
            <Form.Group controlId="producto-codigo">
              <Form.Label>Código *</Form.Label>
              <Form.Control
                name="codigo"
                value={datos.codigo}
                onChange={cambiar}
                disabled={editando}
                isInvalid={Boolean(errores.codigo)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.codigo}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} md={8}>
            <Form.Group controlId="producto-nombre">
              <Form.Label>Nombre *</Form.Label>
              <Form.Control
                name="nombre"
                value={datos.nombre}
                onChange={cambiar}
                isInvalid={Boolean(errores.nombre)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.nombre}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} md={6}>
            <Form.Group controlId="producto-categoria">
              <Form.Label>Categoría *</Form.Label>
              <Form.Control
                name="categoria"
                value={datos.categoria}
                onChange={cambiar}
                isInvalid={Boolean(errores.categoria)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.categoria}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} md={6}>
            <Form.Group controlId="producto-marca">
              <Form.Label>Marca *</Form.Label>
              <Form.Control
                name="marca"
                value={datos.marca}
                onChange={cambiar}
                isInvalid={Boolean(errores.marca)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.marca}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} md={4}>
            <Form.Group controlId="producto-unidad">
              <Form.Label>Unidad</Form.Label>
              <Form.Control name="unidad" value={datos.unidad} onChange={cambiar} />
            </Form.Group>
          </Col>

          <Col xs={12} md={4}>
            <Form.Group controlId="producto-precio">
              <Form.Label>Precio *</Form.Label>
              <Form.Control
                type="number"
                min="1"
                name="precio"
                value={datos.precio}
                onChange={cambiar}
                isInvalid={Boolean(errores.precio)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.precio}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} md={4}>
            <Form.Group controlId="producto-precio-oferta">
              <Form.Label>Precio oferta</Form.Label>
              <Form.Control
                type="number"
                min="1"
                name="precioOferta"
                value={datos.precioOferta}
                onChange={cambiar}
              />
            </Form.Group>
          </Col>

          <Col xs={12} md={6}>
            <Form.Group controlId="producto-stock">
              <Form.Label>Stock *</Form.Label>
              <Form.Control
                type="number"
                min="0"
                name="stock"
                value={datos.stock}
                onChange={cambiar}
                isInvalid={Boolean(errores.stock)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.stock}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12} md={6}>
            <Form.Group controlId="producto-stock-minimo">
              <Form.Label>Stock mínimo *</Form.Label>
              <Form.Control
                type="number"
                min="0"
                name="stockMinimo"
                value={datos.stockMinimo}
                onChange={cambiar}
                isInvalid={Boolean(errores.stockMinimo)}
              />
              <Form.Control.Feedback type="invalid">
                {errores.stockMinimo}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col xs={12}>
            <Form.Group controlId="producto-descripcion">
              <Form.Label>Descripción</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                name="descripcion"
                value={datos.descripcion}
                onChange={cambiar}
              />
            </Form.Group>
          </Col>
        </Row>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onCancelar}>
          Cancelar
        </Button>
        <Button type="submit" variant="warning" className="fw-semibold">
          Guardar
        </Button>
      </Modal.Footer>
    </Form>
  );
}

export default FormularioProducto;
