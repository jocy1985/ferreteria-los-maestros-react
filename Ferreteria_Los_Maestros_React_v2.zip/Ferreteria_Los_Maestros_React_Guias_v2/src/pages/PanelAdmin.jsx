import { useState } from "react";
import { Alert, Button, Col, Container, Modal, Row, Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import MetricaCard from "../components/MetricaCard";
import ProductoAdminRow from "../components/ProductoAdminRow";
import { useProductos } from "../context/ProductosContext";
import { useSesion } from "../context/SesionContext";
import FormularioProducto from "./admin/FormularioProducto";

function PanelAdmin() {
  const { usuario } = useSesion();
  const {
    productos,
    crearProducto,
    actualizarProducto,
    eliminarProducto,
    restablecerProductos,
  } = useProductos();
  const [mostrarModal, setMostrarModal] = useState(false);
  const [productoEditando, setProductoEditando] = useState(null);
  const [mensaje, setMensaje] = useState("");

  const stockBajo = productos.filter((producto) => producto.stock <= producto.stockMinimo).length;
  const metricas = [
    { titulo: "Productos", valor: productos.length },
    { titulo: "Alertas de stock", valor: stockBajo },
    { titulo: "Roles disponibles", valor: 3, descripcion: "Cliente, Empleado y Administrador" },
  ];

  function abrirNuevo() {
    setProductoEditando(null);
    setMostrarModal(true);
  }

  function abrirEditar(producto) {
    setProductoEditando(producto);
    setMostrarModal(true);
  }

  function cerrarFormulario() {
    setMostrarModal(false);
    setProductoEditando(null);
  }

  function guardarProducto(datos) {
    const resultado = productoEditando
      ? actualizarProducto(productoEditando.codigo, datos)
      : crearProducto(datos);

    if (resultado.ok) {
      setMensaje(productoEditando ? "Producto actualizado correctamente." : "Producto creado correctamente.");
      cerrarFormulario();
    }

    return resultado;
  }

  function borrar(producto) {
    if (!window.confirm(`¿Eliminar ${producto.nombre}?`)) return;
    const resultado = eliminarProducto(producto.codigo);
    setMensaje(resultado.ok ? "Producto eliminado correctamente." : resultado.mensaje);
  }

  function restablecer() {
    restablecerProductos();
    setMensaje("Catálogo restablecido a sus datos iniciales.");
  }

  return (
    <Container className="py-5">
      <header className="mb-4">
        <p className="etiqueta">Administrador</p>
        <h1>Panel de administración</h1>
        <p className="lead">Hola, {usuario.nombre}. Gestiona productos e inventario de la tienda.</p>
      </header>

      {mensaje && <Alert variant="success" onClose={() => setMensaje("")} dismissible>{mensaje}</Alert>}

      <Row className="g-4 mb-5">
        {metricas.map((metrica) => (
          <Col xs={12} md={4} key={metrica.titulo}>
            <MetricaCard
              valor={metrica.valor}
              titulo={metrica.titulo}
              descripcion={metrica.descripcion}
            />
          </Col>
        ))}
      </Row>

      <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
          <p className="etiqueta mb-1">CRUD</p>
          <h2 className="h3 mb-0">Gestión de productos</h2>
        </div>
        <div className="d-flex flex-wrap gap-2">
          <Button as={Link} to="/inventario" variant="outline-dark">Ver inventario</Button>
          <Button variant="outline-secondary" onClick={restablecer}>Restablecer</Button>
          <Button variant="warning" className="fw-semibold" onClick={abrirNuevo}>Nuevo producto</Button>
        </div>
      </div>

      <div className="table-responsive border rounded-3">
        <Table hover className="mb-0 align-middle">
          <thead>
            <tr><th>Código</th><th>Producto</th><th>Stock</th><th>Estado</th><th>Acciones</th></tr>
          </thead>
          <tbody>
            {productos.map((producto) => (
              <ProductoAdminRow
                key={producto.codigo}
                producto={producto}
                onEditar={abrirEditar}
                onEliminar={borrar}
              />
            ))}
          </tbody>
        </Table>
      </div>

      <Modal show={mostrarModal} onHide={cerrarFormulario} size="lg" centered>
        {mostrarModal && (
          <FormularioProducto
            key={productoEditando?.codigo ?? "nuevo"}
            producto={productoEditando}
            onGuardar={guardarProducto}
            onCancelar={cerrarFormulario}
          />
        )}
      </Modal>
    </Container>
  );
}

export default PanelAdmin;
